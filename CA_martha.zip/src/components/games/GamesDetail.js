import React, { useState, useEffect } from "react";
import Spinner from "react-bootstrap/Spinner";
import { useParams } from "react-router-dom";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Image from "react-bootstrap/Image";
import { BASE_URL } from "../../constants/api.js";

function GamesDetail() {
	const [detail, setDetail] = useState(null);
	const [loading, setLoading] = useState(true);

	let { id } = useParams();

	let url = BASE_URL + '/' + id;

	useEffect(() => {
		fetch(url)
			.then(response => response.json())
			.then(json => setDetail(json))
			.catch(error => console.log(error))
			.finally(() => setLoading(false));
	}, []);

	if (loading) {
		return <Spinner animation="border" className="spinner" />;
	}

	return (
		<Row>
			<Col md={1} className="detail-image">
				<Image src={detail.background_image} />
			</Col>
			<Col md={4} className="detail_text">
				<h1>{detail.name}</h1>
				<p>
					<b>Rating:</b> {detail.rating}
				</p>
				<p>
					<b>Released:</b> {detail.released}
				</p>
				<p>
					<b>Website:</b> {detail.domain}
				</p>
				<p dangerouslySetInnerHTML={ {__html: detail.description} }>
				</p>

			</Col>
			<Col md={7} >
			</Col>

		</Row>
	);
}

export default GamesDetail;