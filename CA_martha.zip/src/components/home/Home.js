import React from 'react';
import Heading from "../layout/Heading";
import GamesList from "../games/GamesList";

export function Home() {
    return (
    	<>
        	<Heading title="Games you should play" />
        	<GamesList />
        </>
    );
}

export default Home;