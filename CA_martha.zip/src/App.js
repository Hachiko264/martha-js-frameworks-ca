import React from "react";
import Heading from "./components/layout/Heading";
import Subheading from "./components/layout/Subheading";
import Paragraph from "./components/layout/Paragraph";
import Layout from "./components/layout/Layout";
import Double from "./components/layout/Double";
import Button from "./components/layout/Button";
import "./css/style.css";



function App() {
  return (
    <Layout>
    	<Heading title="Title from prop" subtitle="Subtitle from prop" />

    	<Double number={3} multiply={true} />

    	<Paragraph>This will be the children prop inside the component.</Paragraph>
    
    	<Subheading heading="This is the heading" />

		<Button>Click This Button</Button>
    </Layout>
  );
}

export default App;

/*SOURSES
Daniel in class!!!!
https://react-hook-form.com/form-builder/
https://react-bootstrap.github.io/
https://github.com/javascript-repositories/react-module-1-code/blob/step-7/src/components/contact/Contact.js*/